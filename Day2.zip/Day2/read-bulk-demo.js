var fs = require("fs");

//to read full bulk data from file
//use only when file size is small
//Async API
fs.readFile('holidays.txt',"utf8",(err,content) => {
	console.log("File 1 reading completed!!");
	if(err){
		console.log("Error in processing file!!");
		console.log(err.message);
		throw err;
	}
	console.log(content);
}); 

fs.readFile('cricket.txt',"utf8",(err,content) => {
	console.log("File 2 reading completed!!");
	if(err){
		console.log("Error in processing file!!");
		console.log(err.message);
		throw err;
	}
	console.log(content);
}); 


console.log("Finish Line!!");