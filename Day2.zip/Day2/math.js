function sum(arg1,arg2){
	console.log("SUM : "+(arg1+arg2));
}

function diff(arg1,arg2){
	console.log("DIFF : "+(arg1-arg2));
}


exports.title = "Simple Math Calculator";

module.exports.doSum = sum;
//module.exports.doDiff = diff;
exports.doDiff = diff;
exports.doMultiply = function (arg1,arg2){
	console.log("MULTIPLY : "+(arg1*arg2));
};

exports.doDivide = (arg1,arg2) => {
	console.log("DIVIDE : "+(arg1/arg2));
};

