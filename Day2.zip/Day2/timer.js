console.log("Start Line!!");

setTimeout(()=>{
	console.log("Inside setTimeout One!!");
},2000);
console.endtime()

setTimeout(()=>{
	console.log("Inside setTimeout Two!!");
},500);

console.log("Finish Line!!");