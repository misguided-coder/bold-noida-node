var math = require('./math.js');
var accounts = require('./payroll');
console.log("Module imported successfully!!");

console.log(accounts.title);

//var payroll = new accounts.Payroll();
var payroll = accounts.createPayroll();

payroll.hra(12000.00);
payroll.da(12000.00);
payroll.ta(12000.00);


console.log(math.title);
math.title = 'Math Calculator';
console.log(math.title);

math.doSum(12,2);
math.doDiff(12,2);
math.doMultiply(12,2);
math.doDivide(12,2);
