var fs = require("fs");

var readStream1 = fs.createReadStream("holidays.txt","UTF-8");
var readStream2 = fs.createReadStream("cricket.txt","UTF-8");

console.log("===== START SIGNAL =====");

readStream1.on('data',(content)=>{
	console.log(content);
});

readStream1.on('end',()=>{
	console.log("File 1 reading done!!");
});

console.log("===== AFTER FILE 1 SIGNAL =====");

readStream2.on('data',(content)=>{
	console.log(content);
});

readStream2.on('end',()=>{
	console.log("File 2 reading done!!");
});

readStream2.on('end',()=>{
	console.log("File 2 reading done!!");
});

console.log("===== AFTER FILE 2 SIGNAL =====");

console.log("===== END SIGNAL =====");

