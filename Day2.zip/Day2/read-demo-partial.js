var fs = require("fs");

const path = "./holidays.txt"; 

let count = 0;

var readStream = fs.createReadStream(path,{encoding:'UTF-8',autoClose:false,start:40,end:70});

readStream.on('end',()=>{
	console.log("File reading done!!");
	console.log(`Count : ${count}`);
	readStream.close();
});

readStream.on('data',(content)=>{
	console.log(content);
	count++;
});

readStream.on('close',()=>{
	console.log("File closed!!");
});

console.log(readStream.isPaused());
readStream.pause();
console.log("File reading paused!!");
console.log(readStream.isPaused());

setTimeout(()=>{
	if(readStream.isPaused())
		readStream.resume();
},5000);
