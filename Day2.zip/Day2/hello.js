var i = 100;
console.log(i);

console.log("=========================");

for(var idx=0;idx<10;idx++) {
	console.log(idx);
}

console.log("=========================");

function greet(name){
	console.log("GM "+name);
}

greet("Raju");

console.log("=========================");

var date = new Date();
console.log(date);
console.log(date.getYear()+1900);
console.log("=========================");

var array = new Array(34,56,23,56,78,99,12);
console.log(array);
array.push(1000);
array.push(2000);
array.push(3000);
console.log(array);
array.pop();
console.log(array);
array.splice(4,1);
console.log(array);

console.log("=========================");

console.log(Math.random());
console.log(Math.max(23,45,6,34,3));

console.log("=========================");

//IIFE - Immediately Invokable Function Expressions
//Self Invoking Functions
(function (){
	console.log("Doing some initialazation work....");
	//Loading some property files
	//Reading some env variables from os
})();


