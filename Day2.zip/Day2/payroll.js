class Payroll {
	
	constructor() {
		console.log("Inside Payroll constructor!!");
	}

	hra(salary=50000.00) {
		console.log("HRA : "+(salary*.40));
	}

	da(salary=50000.00) {
		console.log("DA : "+(salary*.08));
	}

	ta(salary=50000.00) {
		console.log("TA : "+(salary*.10));
	}
	
}

exports.title  = 'Payroll Related Calculator';
exports.Payroll  = Payroll;
exports.createPayroll  = function() {
	return new Payroll();
};

