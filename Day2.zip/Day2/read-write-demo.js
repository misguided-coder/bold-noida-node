var fs = require("fs");

var readStream = fs.createReadStream("holidays.txt","UTF-8");
var writeStream = fs.createWriteStream("holidays-out.txt","UTF-8");

readStream.pipe(writeStream);
