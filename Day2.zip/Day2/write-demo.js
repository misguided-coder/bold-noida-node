var fs = require("fs");

var writeStream = fs.createWriteStream("details.txt",{flags:'a',encoding:"UTF-8"});


writeStream.on('error',(err)=>{
	console.log("Error in File processing!!");
	console.log(err.message);
});

writeStream.on('finish',()=>{
	console.log("File writing done!!");
});

writeStream.on('close',()=>{
	console.log("File is closed successfully!!");
});

writeStream.on('open',()=>{
	console.log("File is opened successfully!!");

	writeStream.write("Person Details\n");
	writeStream.write("Ritesh Tyagi\n");
	writeStream.write("9999030199\n");
	writeStream.write("HI2TYAGI@YAHOO.COM\n");
	writeStream.end("=================\n");

});
