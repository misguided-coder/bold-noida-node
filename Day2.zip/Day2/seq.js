module.exports = class Seq {

	//Async API is designed to generate unique random sequence values 
	static generate(seed,callback) {

		/* adding a callback into event queue on 
		which event loop is polling */

		setImmediate(()=>{
			console.log("== Generate Sequences Start ==");
			//200 loc
		});

		process.nextTick(()=>{
			console.log("== Generate Sequences End 1 ==");
			//100 loc
		});
		
		process.nextTick(()=>{
			console.log("== Generate Sequences End 2 ==");
			//100 loc
		});

		setImmediate(()=>{
			console.log("== Generateing Sequences ==");
			//100 loc
		});

		setImmediate(()=>{
			console.log("== Generateing Values are ready ==");
			//10 loc
			let values = [Math.random()*seed,Math.random()*seed,Math.random()*seed,Math.random()*seed];
			callback(values);
		});

		console.log("== I am done ==");
	}
}






