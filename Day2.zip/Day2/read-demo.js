var fs = require("fs");

//const path = "C:/bold-noida-node-workspace/holidays.txt"; 
const path = "./holidays.txt"; 

//var readStream = new fs.ReadStream(path);

/*function handle() {
	console.log("File is opened successfully!!");
}*/

let count = 0;

var readStream = fs.createReadStream(path,"UTF-8");

//var readStream = fs.createReadStream(path);
//readStream.addListener('open',handle);

/*readStream.addListener('open',()=>{
	console.log("File is opened successfully!!");
});*/

readStream.on('error',(err)=>{
	console.log("Error in File processing!!");
	console.log(err.message);
});


readStream.on('end',()=>{
	console.log("File reading done!!");
	//50 loc
	console.log("Count :"+count);
});

readStream.on('data',(content)=>{
	console.log("File Content goes here.....");
	if(Buffer.isBuffer(content))
		console.log(content.toString());
	else
		console.log(content);
	count++;
});

readStream.on('close',()=>{
	console.log("File is closed successfully!!");
	//10 loc
});

readStream.on('open',()=>{
	console.log("File is opened successfully!!");
});

readStream.on('readable',()=>{
	console.log("File is ready to read!!");
	var buffer = new Buffer(50);
	readStream.read(buffer);
});

