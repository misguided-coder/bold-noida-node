var fs = require("fs");

var result;

var readStream = fs.createReadStream("holidays.txt","UTF-8");

readStream.on('data',(content)=>{
	console.log("File reading done!!");
	result = content;
});

console.log("Waiting for data to be read!!");
while(!result){
}

console.log("Finish Line!!");
