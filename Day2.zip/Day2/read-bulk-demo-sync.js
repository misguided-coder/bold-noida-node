var fs = require("fs");

//to read full bulk data from file synchronously
//use only when file size is small
//Sync API -- blocking API which will block main thread from running further

console.log("Before File 1!!");
var content1 = fs.readFileSync('holidays.txt',"utf8");
console.log(content1);

console.log("Before File 2!!");
var content2 = fs.readFileSync('cricket.txt',"utf8");
console.log(content2);

console.log("Finish Line!!");