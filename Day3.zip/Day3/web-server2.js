var http = require("http");
var url = require("url");
var qs = require("querystring");


var webserver = http.createServer();

webserver.on('request',(req,res)=>{
	console.log("Server received new request!!");
	console.log(req.url);
	var obj = url.parse(req.url);	
	console.log(obj);
	var parms = qs.parse(obj.query);
	console.log(parms);

	res.writeHead(200,{'Content-Type':'text/html'});
	
	if(obj.pathname.endsWith('news')){
		res.write(`<h1>News about ${parms.city} on day ${parms.day} is Cricket Match</h1>`);
	}else if(obj.pathname.endsWith('weather')){
		res.write(`<h1>Weather is cool in ${parms.city} on day ${parms.day} day</h1>`);
	}else {
		res.writeHead(404,{'Content-Type':'text/html'});
		res.write(`<h1>Page not Found</h1>`);
	}

	res.end();
});

var PORT = process.argv[2] || 4000;
webserver.listen(parseInt(PORT),()=>{
	console.log(`World fastest Webserver is listening on port ${PORT}`);
});

