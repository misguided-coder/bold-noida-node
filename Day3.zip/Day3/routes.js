var fs = require("fs");

const pages = __dirname+"/pages/";

module.exports = (path,res) => {

	console.log(`===== Handling request for '${path}' route =====`);
	
	res.writeHead(200,{'Content-Type':'text/html'});
	
	if(path.endsWith('news')){
		var readStream = fs.createReadStream(pages+"news.html");
		readStream.pipe(res);	
	}else if(path.endsWith('weather')){
		var readStream = fs.createReadStream(pages+"weather.html");
		readStream.pipe(res);	
	} else {
		res.writeHead(404,{'Content-Type':'text/html'});
		var readStream = fs.createReadStream(pages+"404.html");
		readStream.pipe(res);	
	}
};
