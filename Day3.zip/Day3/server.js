var http = require("http");
var url = require("url");
var qs = require("querystring");
var routes = require("./routes");

var webserver = http.createServer();

webserver.on('request',(req,res)=>{
	console.log("Server received new request!!");
	var urlInfo = url.parse(req.url);	
	routes(urlInfo.pathname,res);	
});

exports.start = () => {

	var PORT = process.argv[2] || 4000;

	webserver.listen(parseInt(PORT),()=>{
		console.log(`World fastest Webserver is listening on port ${PORT}`);
	});
};
 
