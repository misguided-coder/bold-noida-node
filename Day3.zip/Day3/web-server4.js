var http = require("http");
var url = require("url");
var qs = require("querystring");
var fs = require("fs");

const pages = __dirname+"/pages/";

var webserver = http.createServer();

webserver.on('request',(req,res)=>{
	console.log("Server received new request!!");
	var urlInfo = url.parse(req.url);	
	res.writeHead(200,{'Content-Type':'text/html'});
	
	if(urlInfo.pathname.endsWith('news')){
		var data = fs.readFileSync(pages+"news.html");
		res.write(data);	
	}else if(urlInfo.pathname.endsWith('weather')){
		data = fs.readFileSync(pages+"weather.html");
		res.write(data);	
	} else {
		res.writeHead(404,{'Content-Type':'text/html'});
		data = fs.readFileSync(pages+"404.html");
		res.write(data);		
	}

	res.end();
});

var PORT = process.argv[2] || 4000;
webserver.listen(parseInt(PORT),()=>{
	console.log(`World fastest Webserver is listening on port ${PORT}`);
});

