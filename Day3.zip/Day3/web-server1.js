var http = require("http");

var webserver = http.createServer();

webserver.on('request',(req,res)=>{
	console.log("Server received new request!!");
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>Hello from World fastest Webserver</h1>");
	res.end();
});

var PORT = process.argv[2] || 4000;
webserver.listen(parseInt(PORT),()=>{
	console.log(`World fastest Webserver is listening on port ${PORT}`);
});

