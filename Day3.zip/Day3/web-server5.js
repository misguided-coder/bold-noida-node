var http = require("http");
var url = require("url");
var qs = require("querystring");
var fs = require("fs");

const pages = __dirname+"/pages/";

var webserver = http.createServer();

webserver.on('request',(req,res)=>{
	console.log("Server received new request!!");
	var urlInfo = url.parse(req.url);	
	res.writeHead(200,{'Content-Type':'text/html'});
	
	if(urlInfo.pathname.endsWith('news')){
		var readStream = fs.createReadStream(pages+"news.html");
		readStream.pipe(res);	
	}else if(urlInfo.pathname.endsWith('weather')){
		var readStream = fs.createReadStream(pages+"weather.html");
		readStream.pipe(res);	
	} else {
		res.writeHead(404,{'Content-Type':'text/html'});
		var readStream = fs.createReadStream(pages+"404.html");
		readStream.pipe(res);	
	}

});

var PORT = process.argv[2] || 4000;
webserver.listen(parseInt(PORT),()=>{
	console.log(`World fastest Webserver is listening on port ${PORT}`);
});

