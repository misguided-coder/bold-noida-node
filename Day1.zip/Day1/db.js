var Seq = require('./seq');

const SEED = 2000;
Seq.generate(SEED,(args)=>{
	console.log(`Generated Sequences are ${args}`);
});

Seq.generate(5000,(args)=>{
	console.log(`Generated Sequences are ${args}`);
	//UI display
});

Seq.generate(100,(args)=>{
	console.log(`Generated Sequences are ${args}`);
	//Save in DB
});
