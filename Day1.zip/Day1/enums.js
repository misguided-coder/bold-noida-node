var array = [34,56,23,232,23,5,3,2];
var person = {name:'Raj',age:24,phone:8972626262,email:'raj@gmail.com'};


//JS 5
for(var value in array) {
	console.log(value);
}

for(var value in person) {
	console.log(value);
}

//JS 6 --- enum 
for(var value of array) {
	console.log(value);
}

/*for(var value of person) {
	console.log(value);
}*/
