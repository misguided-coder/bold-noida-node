class Vehicle {
	
	constructor() {
		console.log("Inside Vehicle constructor!!");
	}

}

//is-a
class Car extends Vehicle {
	
	constructor() {
		super();
		console.log("Inside Car constructor!!");
		this.model = "Audi Q7";
		this.price = 12000000.00;
	}
}

var car = new Car();

console.log(car);
console.log(car.model);
console.log(car.price);

console.log(typeof car);
console.log(car instanceof Car);
