//generator function
function* cars() {
	//10 loc
	yield "Audi Q7";
	//10 loc
	yield "Audi Q5";
	//5 loc
	yield "Audi A2";
	//5 loc
	yield "Merc CLA";
	//20 loc
	yield "Jaguar XF";
	//20 loc
	yield "Jaguar XE";
}

var itr = cars();

//console.log(itr);
//console.log(itr.next());

/*console.log(itr.next().value);
console.log(itr.next().value);

//200 loc

console.log(itr.next().value);
console.log(itr.next().value);
console.log(itr.next().value);
console.log(itr.next().value);
console.log(itr.next().value);
console.log(itr.next().value);*/

for(var val of itr){
	console.log(val);
}

