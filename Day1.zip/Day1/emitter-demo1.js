var events = require("events");

var emitter = new events.EventEmitter();

//Subscriber 1
function mailSender() {
	console.log("Race just started and mail has been sent!!");
}

//Subscriber 2
function whatsAppSender() {
	console.log("Race just started and whats app message has been sent!!");
}

//Subscriber 3
function smsSender() {
	console.log("Race just started and sms has been sent!!");
}

emitter.addListener('race_start',mailSender); 
emitter.on('race_start',whatsAppSender); 
//emitter.on('race_start',smsSender); 
emitter.once('race_start',smsSender); 
emitter.on('race_over',(day,time,players) => {
	console.log(`Race just got over at ${time} of ${day} and Players Count was ${players}`);
}); 

emitter.on('winner_announced',(name) => {
	console.log(`Race Winner is Mr. ${name}!!`);
}); 

emitter.on('price_declared',(prize_money) => {
	console.log(`Price for winner is Rs/. ${prize_money}!!`);
}); 


//Publisher 
emitter.emit('race_start'); 
//emitter.off('race_start',smsSender); //smsSender unsubscribing from race_start event
emitter.emit('race_start'); 

emitter.removeAllListeners('race_start');

emitter.emit('race_start'); 
emitter.emit('race_over','Friday','6PM','12 Players'); 
emitter.emit('winner_announced','Mohan');
emitter.emit('price_declared',1200000.00);
 


