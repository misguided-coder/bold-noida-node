var BankService = require('./bank').BankService;
console.log("Module imported successfully!!");

var bankService = new BankService('HDFC Bank');

bankService.on('account_opened',(title,accountNo) => {
	console.log(`Email Sent - New Account No ${accountNo} in ${title}`);
});

bankService.on('account_opened',(title,accountNo) => {
	console.log(`SMS Sent - New Account No ${accountNo} in ${title}`);
});

bankService.open();
bankService.transfer(2090,1020,800000000.00);

