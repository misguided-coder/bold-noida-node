console.log(__dirname);
console.log("=========================");
console.log(__filename);
console.log("=========================");

/*setTimeout(()=>{
	console.log("Now I will start my work......");
},5000);*/ //ms

console.log("I am in hurry and will finish my work now......");
console.log("I am in hurry and will finish my work now......");


/*setInterval(()=>{
	console.log("Now I will start my work continously......");
},2000);*/ //ms


var buffer1 = new Buffer("Hello ji","UTF8");
console.log(buffer1);
//console.log(buffer1.toString());

var buffer2 = new Buffer([13,45,22,23,23,34,55,66,77]);
console.log(buffer2);
console.log(buffer2.toString());

console.log(buffer1.compare(buffer2));
console.log(buffer1.equals(buffer2));






