console.log("Start Line!!");

//Timer Phase Event Queue
setTimeout(()=>{
	console.log("Inside setTimeout One!!");
	
	//Check Phase Event Queue
	setImmediate(()=>{
		console.log("Inside setImmediate One !!");
	});
},0);

//Timer Phase Event Queue
setTimeout(()=>{
	console.log("Inside setTimeout Two!!");
	
	//Check Phase Event Queue
	setImmediate(()=>{
		console.log("Inside setImmediate Two !!");
	});
},0);

//Next Tick Queue
process.nextTick(()=>{
	console.log("Inside nextTick!!");
});

console.log("Finish Line!!");