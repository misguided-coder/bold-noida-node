class Car {
	
	constructor(model,price=500000.00,color='Yellow',speed=200) {
		console.log("Inside Car constructor!!");
		this.model = model;
		this.price = price;
		this.color = color;
		this.speed = speed;
	}

	speedUp() {
		this.speed = this.speed + 50;
	}

	applyBrake() {
		this.speed = this.speed - 50;
	}
	
}


var car1 = new Car('BMW X6',3400000.00);
var car2 = new Car('BMW X1',3780000.00);
var car3 = new Car('BMW X1',3780000.00,"Black");
var car4 = new Car('Jaguar XF');


console.log(car1.model);
console.log(car1.price);
console.log(car1.color);

car1.speedUp();
car1.speedUp();
car1.speedUp();
car1.speedUp();

console.log(car1.speed);

console.log(car2.model);
console.log(car2.price);
console.log(car2.color);

console.log(car3.model);
console.log(car3.price);
console.log(car3.color);
