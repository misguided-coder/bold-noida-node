var fs = require("fs");

console.log("Start Line!!");

fs.readFile('holidays.txt',"utf8",(err,content) => {

	setTimeout(()=>{
		console.log("Inside setTimeout!!");
	},0);
	
	setImmediate(()=>{
		console.log("Inside setImmediate!!");
	});

	setImmediate(()=>{
		console.log("Inside setImmediate!!");
	});

	process.nextTick(()=>{
		console.log("Inside nextTick!!");
	});

	console.log("File reading completed!!");
	console.log(content);
}); 

console.log("Finish Line!!");