var EventEmitter = require("events").EventEmitter;

class BankService extends EventEmitter {
	
	constructor(title) {
		super();	
		console.log("Inside BankService constructor!!");
		this.title = title;
	}

	open() {
		//DB Calls
		console.log("Inside BankService open!!");
		let accountNo = Math.floor(Math.random()*1000);
		this.emit("account_opened",this.title,accountNo);
	}

	close(accountNo) {
		//DB Calls
		console.log("Inside BankService close!!");
		this.emit("account_closed",accountNo);
	}

	withdraw(accountNo,amount) {
		//DB Calls
		console.log("Inside BankService withdraw!!");
		this.emit("account_debited",accountNo,amount);
	}

	deposit(accountNo,amount) {
		//DB Calls
		console.log("Inside BankService deposit!!");
		this.emit("account_credited",accountNo,amount);
	}	

	transfer(fromAccount,toAccount,amount) {
		//DB Calls
		console.log("Inside BankService transfer!!");
		this.withdraw(fromAccount,amount);
		this.deposit(toAccount,amount)
	}	
}


exports.BankService = BankService;