var fs = require("fs");

console.log("Start Line!!");

setImmediate(()=>{
	console.log("Inside setImmediate One !!");
});

setTimeout(()=>{
	console.log("Inside setTimeout!!");
},0);

setImmediate(()=>{
	console.log("Inside setImmediate Two !!");
});

process.nextTick(()=>{
	console.log("Inside nextTick!!");
});

console.log("Finish Line!!");