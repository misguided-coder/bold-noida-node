var express = require("express");
var routes = require("./routes");

var app = express();

app.use("/bold",routes);

var PORT = 4000;

app.listen(PORT,()=>{
	console.log(`Express Server is ready on port ${PORT}`);
});

