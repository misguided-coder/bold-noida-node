var express = require("express");

var routes = new express.Router();

routes.get("/news",(req,res)=>{
	res.send("News Page");
});

routes.get("/weather",(req,res)=>{
	res.sendFile(__dirname+"/pages/weather.html");
});

routes.get("/",(req,res)=>{
	res.send("Home Page");
});

routes.get("*",(req,res)=>{
	res.send("Page No Found");
});

module.exports = routes;

