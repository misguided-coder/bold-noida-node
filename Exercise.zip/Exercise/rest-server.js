var express = require("express");
var bodyParser = require("body-parser");

var app = express();
app.use(bodyParser.json());

const cars = [
	{"vin":100,"name":"Audi A5","price":2400000.00},
	{"vin":101,"name":"Audi Q7","price":9000000.00}
];

//Read all cars
app.get("/api/cars",(req,res)=>{
	res.header(200).send(cars);
});

//Read single car
app.get("/api/car/:vin",(req,res)=>{
	let vin = parseInt(req.params.vin);
	//DB calls
	for(let i=0;i<cars.length;i++){
		var car = cars[i];
		if(car.vin == vin){
			return res.status(200).send(car);
		}
	}
	return res.status(404).send({"success":false,"message":`car with ${vin} not found`});
});

//Add new car
app.post("/api/car",(req,res)=>{

	if(!req.body.name || req.body.name.trim().length <= 0)
		res.status(404).send({"success":false,"message":`Name is required`});
	
	let car = {
		"vin":cars.length + 100,
		"name":req.body.name,
		"price":req.body.price
	};

	cars.push(car);
	res.status(200).send({"success":true,"message":`car with ${car.vin} added to db`});
});

//Update an existing car
app.put("/api/car/:vin",(req,res)=>{
});

//Delete an existing car
app.delete("/api/car/:vin",(req,res)=>{
});

var PORT = 4000;
app.listen(PORT,()=>{
	console.log(`Express Server is ready on port ${PORT}`);
});

