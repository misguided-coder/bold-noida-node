var express = require("express");

var app = express();

app.get("/news",(req,res)=>{
	res.send("News Page");
});

app.get("/weather",(req,res)=>{
	res.send("Weather Page");
});

app.get("/",(req,res)=>{
	res.send("Home Page");
});

app.get("*",(req,res)=>{
	res.send("Page No Found");
});

var PORT = 4000;
app.listen(PORT,()=>{
	console.log(`Express Server is ready on port ${PORT}`);
});

